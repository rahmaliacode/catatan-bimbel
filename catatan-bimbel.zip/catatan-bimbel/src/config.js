export const SUPABASE_URL = 'https://tsweqgmkzzphdzbfeioe.supabase.co';
export const SUPABASE_KEY = 'sb_publishable_MQ7hpWxia_1Tw1qtkixPsw_0ltapTj4';
