create table public.checklist_settings (
 user_id uuid primary key references auth.users(id) on delete cascade,
 items jsonb not null check (jsonb_typeof(items)='array' and jsonb_array_length(items)<=50)
);
alter table public.checklist_settings enable row level security;
grant select,insert,update,delete on public.checklist_settings to authenticated;
revoke all on public.checklist_settings from anon;
create policy checklist_settings_select on public.checklist_settings for select to authenticated using ((select auth.uid())=user_id);
create policy checklist_settings_insert on public.checklist_settings for insert to authenticated with check ((select auth.uid())=user_id);
create policy checklist_settings_update on public.checklist_settings for update to authenticated using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
create policy checklist_settings_delete on public.checklist_settings for delete to authenticated using ((select auth.uid())=user_id);
alter table public.reports add column checklist_items jsonb check (checklist_items is null or (jsonb_typeof(checklist_items)='array' and jsonb_array_length(checklist_items)<=50));
