import { createClient } from 'npm:@supabase/supabase-js@2.117.2';
const publicKey = 'sb_publishable_MQ7hpWxia_1Tw1qtkixPsw_0ltapTj4';
const cors = {'Access-Control-Allow-Origin':'https://rahmaliacode.github.io','Access-Control-Allow-Headers':'apikey, authorization, content-type, x-client-info','Access-Control-Allow-Methods':'POST, OPTIONS'};
function reply(body:object,status=200){return new Response(JSON.stringify(body),{status,headers:{...cors,'Content-Type':'application/json','Cache-Control':'no-store'}})}
Deno.serve(async req=>{
 if(req.method==='OPTIONS')return new Response(null,{status:204,headers:cors});
 if(req.method!=='POST')return reply({error:'Metode tidak didukung.'},405);
 // Pre-authentication registration requires the app's public API key, not a user session.
 if(req.headers.get('apikey')!==publicKey)return reply({error:'Akses tidak valid.'},401);
 const origin=req.headers.get('origin');
 if(origin && origin!=='https://rahmaliacode.github.io')return reply({error:'Asal permintaan tidak diizinkan.'},403);
 try{
  if(Number(req.headers.get('content-length')||0)>4096)return reply({error:'Permintaan terlalu besar.'},413);
  const body=await req.text();if(body.length>4096)return reply({error:'Permintaan terlalu besar.'},413);
  const {email,password}=JSON.parse(body);
  if(typeof email!=='string'||email.length>254||!/^\S+@\S+\.\S+$/.test(email)||typeof password!=='string'||password.length<8||password.length>128)return reply({error:'Gunakan email valid dan kata sandi 8–128 karakter.'},400);
  const secret=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');const url=Deno.env.get('SUPABASE_URL');
  if(!secret||!url)return reply({error:'Pendaftaran sementara belum tersedia.'},503);
  const admin=createClient(url,secret,{auth:{persistSession:false,autoRefreshToken:false}});
  const ip=req.headers.get('x-forwarded-for')?.split(',')[0]?.trim()||'unknown';
  const cryptoKey=await crypto.subtle.importKey('raw',new TextEncoder().encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);
  const signature=await crypto.subtle.sign('HMAC',cryptoKey,new TextEncoder().encode(ip));
  const key=Array.from(new Uint8Array(signature)).map(b=>b.toString(16).padStart(2,'0')).join('');
  const limit=await admin.rpc('check_registration_limit',{p_key:key});
  if(limit.error)return reply({error:'Pendaftaran sementara belum tersedia.'},503);
  if(!limit.data)return reply({error:'Terlalu banyak percobaan. Coba lagi satu jam mendatang.'},429);
  const {error}=await admin.auth.admin.createUser({email:email.trim().toLowerCase(),password,email_confirm:true});
  if(error)return reply({error:'Akun tidak dapat dibuat. Email mungkin sudah terdaftar; coba masuk.'},400);
  return reply({success:true});
 }catch{return reply({error:'Pendaftaran gagal. Silakan coba lagi.'},400)}
});
