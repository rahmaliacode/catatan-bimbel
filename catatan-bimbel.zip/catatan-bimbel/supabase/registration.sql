create table public.registration_limits (
 key text primary key,
 hour timestamptz not null,
 attempts integer not null default 0
);
alter table public.registration_limits enable row level security;
revoke all on public.registration_limits from public,anon,authenticated;
grant select,insert,update,delete on public.registration_limits to service_role;
create function public.check_registration_limit(p_key text) returns boolean
language plpgsql security invoker set search_path = '' as $$
declare n integer;
begin
 insert into public.registration_limits(key,hour,attempts)
 values(p_key,date_trunc('hour',now()),1)
 on conflict(key) do update set
 attempts=case when registration_limits.hour=date_trunc('hour',now()) then registration_limits.attempts+1 else 1 end,
 hour=date_trunc('hour',now())
 returning attempts into n;
 return n <= 5;
end $$;
revoke all on function public.check_registration_limit(text) from public,anon,authenticated;
grant execute on function public.check_registration_limit(text) to service_role;
