create table public.students (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 name text not null check (length(trim(name)) between 1 and 100),
 level text not null default '' check (length(level) <= 80),
 created_at timestamptz not null default now(),
 unique (id,user_id)
);
create index students_user_name on public.students(user_id,name);
create table public.reports (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 student_id uuid not null,
 date date not null,
 subject text not null check (length(trim(subject)) between 1 and 100),
 topic text not null check (length(trim(topic)) between 1 and 200),
 attended boolean not null default false,
 material boolean not null default false,
 practice boolean not null default false,
 understood boolean not null default false,
 homework boolean not null default false,
 notes text not null default '' check (length(notes) <= 2000),
 next_plan text not null default '' check (length(next_plan) <= 1000),
 created_at timestamptz not null default now(),
 foreign key(student_id,user_id) references public.students(id,user_id) on delete cascade
);
create index reports_user_date on public.reports(user_id,date desc);
create index reports_student_user on public.reports(student_id,user_id);
alter table public.students enable row level security;
alter table public.reports enable row level security;
grant select,insert,update,delete on public.students, public.reports to authenticated;
revoke all on public.students, public.reports from anon;
create policy students_select on public.students for select to authenticated using ((select auth.uid())=user_id);
create policy students_insert on public.students for insert to authenticated with check ((select auth.uid())=user_id);
create policy students_update on public.students for update to authenticated using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
create policy students_delete on public.students for delete to authenticated using ((select auth.uid())=user_id);
create policy reports_select on public.reports for select to authenticated using ((select auth.uid())=user_id);
create policy reports_insert on public.reports for insert to authenticated with check ((select auth.uid())=user_id);
create policy reports_update on public.reports for update to authenticated using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
create policy reports_delete on public.reports for delete to authenticated using ((select auth.uid())=user_id);
