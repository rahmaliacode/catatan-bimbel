# Catatan Bimbel

Aplikasi checklist laporan belajar siswa. GitHub Pages untuk frontend, Supabase untuk autentikasi dan database.

## Fitur
- Daftar dan masuk pengajar
- Tambah, edit, hapus siswa
- Laporan per pertemuan: tanggal, mata pelajaran, materi, 5 checklist, catatan dan rencana berikutnya
- Filter laporan berdasarkan siswa dan bulan
- Ringkasan siswa, pertemuan dan pemahaman materi
- Mode contoh yang tidak menyimpan data

## Pengembangan
`npm ci` lalu `npm run dev`. Jalankan `npm run build` untuk build produksi.

Konfigurasi browser berada di `src/config.js` dan hanya berisi URL Supabase serta publishable key. Jangan memasukkan service_role atau secret key. Schema berada di `supabase/schema.sql`; seluruh tabel memiliki RLS berbasis pemilik akun.

GitHub Pages dipublikasikan otomatis dari branch `main` melalui GitHub Actions. Source Pages harus diatur ke GitHub Actions.
