export const weekdays=['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
export const weekday=date=>new Date(date+'T12:00:00+07:00').getUTCDay();
export const forDate=(schedules,date)=>schedules.filter(s=>s.active&&Number(s.weekday)===weekday(date)).sort((a,b)=>a.start_time.localeCompare(b.start_time));
export const overlaps=(a,b)=>a.active&&b.active&&Number(a.weekday)===Number(b.weekday)&&a.start_time<b.end_time&&a.end_time>b.start_time;
