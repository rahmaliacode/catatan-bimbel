create table public.schedules (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 student_id uuid not null,
 subject text not null check(length(trim(subject)) between 1 and 100),
 weekday smallint not null check(weekday between 0 and 6),
 start_time time not null,
 end_time time not null check(end_time > start_time),
 active boolean not null default true,
 created_at timestamptz not null default now(),
 unique(id,user_id),
 foreign key(student_id,user_id) references public.students(id,user_id) on delete cascade
);
create index schedules_user_day on public.schedules(user_id,weekday,start_time);
create index schedules_student_user on public.schedules(student_id,user_id);
alter table public.schedules enable row level security;
revoke all on public.schedules from anon;
grant select,insert,update,delete on public.schedules to authenticated;
create policy schedules_select on public.schedules for select to authenticated using ((select auth.uid())=user_id);
create policy schedules_insert on public.schedules for insert to authenticated with check ((select auth.uid())=user_id);
create policy schedules_update on public.schedules for update to authenticated using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
create policy schedules_delete on public.schedules for delete to authenticated using ((select auth.uid())=user_id);
alter table public.reports add column schedule_id uuid;
alter table public.reports add constraint reports_schedule_owner foreign key(schedule_id,user_id) references public.schedules(id,user_id) on delete set null (schedule_id);
create unique index reports_schedule_date on public.reports(schedule_id,date) where schedule_id is not null;
