begin;
create table public.subjects (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 name text not null check(length(trim(name)) between 1 and 100),
 active boolean not null default true,
 created_at timestamptz not null default now(),
 unique(id,user_id)
);
create unique index subjects_user_normalized_name on public.subjects(user_id,lower(regexp_replace(trim(name),'\s+',' ','g')));
alter table public.subjects enable row level security;
revoke all on public.subjects from anon;
grant select,insert,update,delete on public.subjects to authenticated;
create policy subjects_select on public.subjects for select to authenticated using ((select auth.uid())=user_id);
create policy subjects_insert on public.subjects for insert to authenticated with check ((select auth.uid())=user_id);
create policy subjects_update on public.subjects for update to authenticated using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
create policy subjects_delete on public.subjects for delete to authenticated using ((select auth.uid())=user_id);
insert into public.subjects(user_id,name)
select user_id,min(regexp_replace(trim(subject),'\s+',' ','g')) from (
 select user_id,subject from public.reports union all select user_id,subject from public.schedules
) source group by user_id,lower(regexp_replace(trim(subject),'\s+',' ','g'));
alter table public.schedules add column subject_id uuid;
alter table public.reports add column subject_id uuid;
update public.schedules s set subject_id=m.id from public.subjects m where s.user_id=m.user_id and lower(regexp_replace(trim(s.subject),'\s+',' ','g'))=lower(m.name);
update public.reports r set subject_id=m.id from public.subjects m where r.user_id=m.user_id and lower(regexp_replace(trim(r.subject),'\s+',' ','g'))=lower(m.name);
alter table public.schedules add constraint schedules_subject_owner foreign key(subject_id,user_id) references public.subjects(id,user_id) on delete set null(subject_id);
alter table public.reports add constraint reports_subject_owner foreign key(subject_id,user_id) references public.subjects(id,user_id) on delete set null(subject_id);
create index schedules_subject_user on public.schedules(subject_id,user_id);
create index reports_subject_user on public.reports(subject_id,user_id);
commit;
