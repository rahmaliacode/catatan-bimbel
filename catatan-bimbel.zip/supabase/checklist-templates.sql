create table public.checklist_templates (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 subject_id uuid not null,
 student_id uuid,
 items jsonb not null check(jsonb_typeof(items)='array' and jsonb_array_length(items)<=50),
 unique nulls not distinct (user_id,subject_id,student_id),
 foreign key(subject_id,user_id) references public.subjects(id,user_id) on delete cascade,
 foreign key(student_id,user_id) references public.students(id,user_id) on delete cascade
);
create index checklist_templates_subject_user on public.checklist_templates(subject_id,user_id);
create index checklist_templates_student_user on public.checklist_templates(student_id,user_id);
alter table public.checklist_templates enable row level security;
revoke all on public.checklist_templates from anon;
grant select,insert,update,delete on public.checklist_templates to authenticated;
create policy templates_select on public.checklist_templates for select to authenticated using ((select auth.uid())=user_id);
create policy templates_insert on public.checklist_templates for insert to authenticated with check ((select auth.uid())=user_id);
create policy templates_update on public.checklist_templates for update to authenticated using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
create policy templates_delete on public.checklist_templates for delete to authenticated using ((select auth.uid())=user_id);
